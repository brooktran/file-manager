package org.jeelee.utils;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.DeviceData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;
import org.junit.Test;

public class SleakTest {
	static Display display;

	static Shell shell;

	static List list;

	static Canvas canvas;

	static Image image;

	@Test
	public void test() {
		
		
		 DeviceData data = new DeviceData();
		 data.tracking = true;
		 display = new Display(data);
//		display = new Display();
		 Sleak sleak = new Sleak();
		 sleak.open();

		shell = new Shell(display);
		shell.setLayout(new FillLayout());
		list = new List(shell, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL
				| SWT.H_SCROLL);
		list.setItems(Program.getExtensions());
		canvas = new Canvas(shell, SWT.BORDER);
		canvas.addPaintListener(new PaintListener() {
			@Override
			public void paintControl(PaintEvent e) {
				if (image != null) {
					e.gc.drawImage(image, 0, 0);
				}
			}
		});
		list.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
//				image = null; // potentially leak one image
				
				if (image != null) {
	                image.dispose();
	                image = null;
	            }
				
				String[] selection = list.getSelection();
				if (selection.length != 0) {
					Program program = Program.findProgram(selection[0]);
					if (program != null) {
						ImageData imageData = program.getImageData();
						if (imageData != null) {
							if (image != null) {
								image.dispose();
							}
							image = new Image(display, imageData);
						}
					}
				}
				canvas.redraw();
			}
		});
		shell.setSize(shell.computeSize(SWT.DEFAULT, 200));
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

}
