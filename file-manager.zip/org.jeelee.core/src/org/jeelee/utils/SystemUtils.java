package org.jeelee.utils;

public class SystemUtils
{
  public static String lineSeparator()
  {
    return System.getProperty("line.separator");
  }
}

/* Location:           F:\backup\SystemDesktop\org.jeelee.core_2.1.0.201208282112.jar
 * Qualified Name:     org.jeelee.utils.SystemUtils
 * JD-Core Version:    0.6.0
 */