package org.jeelee.core;

public class JeeleeMessages
{
  public static final String LINE_NUMBER = "line.number";
  public static final String TABLE_CONFIGURE = "table.configure";
  public static final String ARROW_UP = "arrow.up";
  public static final String ARROW_DOWN = "arrow.down";
  public static final String PREFERENCE_SET_AS_DEFAULT = "set.as.default";
  public static final String DEFAULT = "default";
  public static final String SURE_TO_DELETE = "sure.to.delete";
  public static final String APPLICATION_ALREADY_RUNNING = "application.already.running";
  public static final String ADD = "add";
  public static final String DELETE = "delete";
  public static final String ERROR = "error";
}

/* Location:           F:\backup\SystemDesktop\org.jeelee.core_2.1.0.201208282112.jar
 * Qualified Name:     org.jeelee.core.JeeleeMessages
 * JD-Core Version:    0.6.0
 */