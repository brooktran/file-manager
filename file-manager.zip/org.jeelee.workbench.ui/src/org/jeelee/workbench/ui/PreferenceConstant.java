package org.jeelee.workbench.ui;

public interface PreferenceConstant {

	String EXIT_PROMPT_ON_CLOSE_LAST_WINDOW = "exit.prompt.on.close.last.window";
	String	EXIT_DIRECTLY	= "exit.application.directly";

}
