package org.jeelee.filemanager.core.filters;

public interface Catalog {

	String getId();

	void setId(String id);

	String getName();

	void setName(String name);

	String getImage();

	void setImage(String image);
	
//	Object getValue();
//	void setValue(Object value);
}