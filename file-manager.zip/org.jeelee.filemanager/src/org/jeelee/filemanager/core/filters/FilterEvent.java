package org.jeelee.filemanager.core.filters;

import java.util.EventObject;

public class FilterEvent extends EventObject{

	public FilterEvent(Object source) {
		super(source);
	}

}
