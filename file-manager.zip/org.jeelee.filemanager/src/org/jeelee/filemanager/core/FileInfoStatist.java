/* FileInfoStatist.java 
 * Copyright (c) 2012 by Brook Tran
 * All rights reserved.
 * 
 * The copyright of this software is own by the authors.
 * You may not use, copy or modify this software, except
 * in accordance with the license agreement you entered into 
 * with the copyright holders. For details see accompanying license
 * terms.
 */
package org.jeelee.filemanager.core;

import java.nio.file.attribute.BasicFileAttributes;


/**
 * <B>FileInfoStatist</B>
 * 
 * @author Brook Tran. Email: <a href="mailto:Brook.Tran.C@gmail.com">Brook.Tran.C@gmail.com</a>
 * @since org.jeelee.filemanager 2012-8-14 created
 */
public interface FileInfoStatist <T>{

	void visitFile(T t, BasicFileAttributes attrs);

}
