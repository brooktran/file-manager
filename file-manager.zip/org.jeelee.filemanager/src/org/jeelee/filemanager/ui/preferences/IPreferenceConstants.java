package org.jeelee.filemanager.ui.preferences;

public interface IPreferenceConstants {
	public static final String COMMAND_COPY_PATH = "command.copy.path";
	public static final String COMMAND_EXPLORE = "command.explore";
	public static final String COMMAND_RUN = "command.run";
	public static final String COMMAND_SHELL = "command.open";
}
