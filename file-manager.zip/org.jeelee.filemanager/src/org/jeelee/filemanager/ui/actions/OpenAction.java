package org.jeelee.filemanager.ui.actions;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.jeelee.filemanager.core.operation.OpenOperation;
import org.jeelee.filemanager.ui.FileManagerActivator;
import org.jeelee.filemanager.ui.Messages;
import org.jeelee.filemanager.ui.views.model.FileExplorer;

public class OpenAction extends SelectionDispatchAction  {
	public static final String ID=Messages.OPEN;

	public OpenAction(FileExplorer fileExplorer) {
		super(fileExplorer);
		setId(ID);
		FileManagerActivator.RESOURCES.configAction(this,ID );
	}

	@Override
	public void run(IStructuredSelection selection) {
		OpenOperation op=new OpenOperation(fileExplorer.getPathProvider());
	}
}
